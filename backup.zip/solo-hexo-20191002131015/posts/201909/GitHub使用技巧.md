title: GitHub使用技巧
date: '2019-09-09 09:15:07'
updated: '2019-09-09 09:15:30'
tags: [Git]
permalink: /articles/2019/09/09/1567991707539.html
---
![](https://img.hacpai.com/bing/20190709.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

玩github已经好多年了，github不但是程序员们的最爱，更是一个搜索的宝库。
在github里面我们不仅可以搜到我们想要的轮子，而且还能搜多很多开源的项目，以及一些知识汇总等等好玩有趣的东西。
今天咱们不聊github针对程序员的一些操作，例如:如何注册创建账号、也不想讲如何创建仓库、代码提交、解决冲突等一些专业性稍微有点强的知识，写这一篇文章，是为了让大家快速找到我们想要的东西，或者讲的是github使用的一些小技巧等等。
#### 1.搜热门：GitHub Trend 和 GitHub Topic
* [GitHub Trend](https://github.com/trending) 
页面总结了每天/每周/每月周期的热门 Repositories 和 Developers，你可以看到在某个周期处于热门状态的开发项目和开发者。
* [GitHub Topic](https://github.com/topics) 
展示了最新和最流行的讨论主题，在这里你不仅能够看到开发项目，还能看到更多非开发技术的讨论主题，比如 Job、Chrome 浏览器等。

#### 2. 搜开发者
坊间传闻人事招聘开发类员工时，招聘对象在 GitHub 贡献会是重要的参考指标之一。GitHub 作为优秀国产开源软件的集散地之一，埋藏了不少出色的开发者，所以在寻找国产软件的时候，可以尝试先找国内开发者。利用 GitHub 强大的搜索功能，增加几个搜索参数即可轻松找到「目标人物」。
（注：GitHub 官方还支持很多搜索条件，在 [这里](https://help.github.com/articles/about-searching-on-github/) 可以查看官方出品的搜索技巧。）
![ 找开发者](http://resource.sunnyfanfan.com/soloBlog/Git/3168340-0be0c6f837a3424f.jpg)

比如需要寻找国产软件，首先想到的应该是在 GituHub 上找国内开发者，搜索时设置 location 为 China，如果你要寻找使用 javascript 语言开发者，则再增加 language 为 javascript，整个搜索条件就是：language:javascript location:china，从搜索结果来看，我们找到了近 17000 名地区信息填写为 china 的 javascript 开发者，朋友们熟悉的阮一峰老师排在前列。根据官方指引，搜索 GitHub 用户时还支持使用 followers、in:fullname 组合条件进行搜索。
![使用组合条件进行搜索](http://resource.sunnyfanfan.com/soloBlog/Git/3168340-6aa160c565cb127e.jpg)
![搜索条件<language:javascript location:china>](http://resource.sunnyfanfan.com/soloBlog/Git/3168340-2c41ca54030afb5d.jpg)

#### 3.搜项目
我们需要在 GitHub 上找到优秀的项目和工具，同样，通过关键字或者设置搜索条件帮助你事半功倍找到好资源。我的使用习惯是先用某些关键词搜索，得到的搜索结果优先展示一些现成的软件和工具。
![ 找项目](http://resource.sunnyfanfan.com/soloBlog/Git/3168340-dbb5f699bd6d0944.jpg)
**Awesome + 关键字**

Awesome 似乎已经成为不少 GitHub 项目喜爱的命名之一，比如前面提及要找到优秀的 Windows 软件，可以尝试搜索 `Awesome windows`，得到这样的搜索结果：

![搜索结果](http://resource.sunnyfanfan.com/soloBlog/Git/3168340-c7a1191e053c5938)

排名前列的结果出现了 [Windows/Awesome 项目](https://github.com/Awesome-Windows/Awesome)，这里集合了 Windows 上优质和精选的最佳应用程序及工具列表。在这里，我收集了这些 Awesome 主题的优秀项目：
[The awesome manifesto](https://github.com/sindresorhus/awesome)
[Awesome iOS frameworks](https://github.com/vsouza/awesome-ios)
[Awesome wesome Android libraries and resources](https://github.com/JStumpp/awesome-android)。

**设置搜索条件**

如果你明确需要寻找某类特定的项目，比如用某种语言开发、Stars 数量需要达到标准的项目，在搜索框中直接输入搜索条件即可。其中用于发现项目，我的用法是灵活运用下面几个搜索条件：`stars:`、`language:`、`forks:`，其实就是设置项目收藏、开发语言、派生的搜索条件，比如输入 `stars:>=500 language:javascript`，[得到的结果](https://github.com/search?q=stars%3A%3E%3D500+language%3Ajavascript) 就是收藏大于和等于 500 的 javascript 项目，排名前列是开源代码库和课程项目 freeCodeCamp、大热门的 Vue 和 React 项目。

![搜索条件<stars:>=500 language:javascript>](http://resource.sunnyfanfan.com/soloBlog/Git/3168340-5d4e271a4c13874b)


如果觉得记住这些搜索条件略显繁琐的话，使用 GitHub 提供的 [高级搜索功能](https://github.com/search/advanced)，同样可用自定义条件进行搜索。或者参考官方给出的帮助指南 [Searching on GitHub](https://help.github.com/articles/searching-on-github/) ，里面有更多关于项目、代码、评论、问题等搜索技巧。

![高级搜索功能](http://resource.sunnyfanfan.com/soloBlog/Git/3168340-e568efef520ba589)


下面是 GitHub 上影响力颇大的项目，仅列举部分：

*   [free-programming-books](https://github.com/vhf/free-programming-books)：整理了所有和编程相关的免费书籍，同时也有 [中文版项目](https://github.com/vhf/free-programming-books/blob/master/free-programming-books-zh.md)。
*   [github-cheat-sheet](https://github.com/tiimgreen/github-cheat-sheet/)：集合了使用 GitHub 的各种技巧。
*   [android-open-project](https://github.com/Trinea/android-open-project)：涵盖 Android 开发的优秀开源项目。
*   [chinese-independent-developer](https://github.com/1c7/chinese-independent-developer)：聚合所有中国独立开发者的项目。

#### 结语

GitHub 网站拥有很多优秀的开源项目，用好 GitHub 的搜索功能，我们既可以使用官方提供的高级搜索和 Topic、Trend 专题页面，也可以学习组合使用搜索条件的方法，主动发现更多好用的项目和工具。


参考链接
* 1.[https://sspai.com/post/46061](https://sspai.com/post/46061)
* 2.[https://help.github.com/en/articles/about-searching-on-github](https://help.github.com/en/articles/about-searching-on-github)
* 3.[https://github.com/xirong/my-git/blob/master/how-to-use-github.md](https://github.com/xirong/my-git/blob/master/how-to-use-github.md)





