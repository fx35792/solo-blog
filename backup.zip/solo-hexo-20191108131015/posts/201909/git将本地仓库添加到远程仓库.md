title: git将本地仓库添加到远程仓库
date: '2019-09-09 08:52:04'
updated: '2019-09-09 08:52:04'
tags: [Git]
permalink: /articles/2019/09/09/1567990323974.html
---
在开发的过程中:遇到下面两种场景
场景一：
我们git clone一个新的项目后，我们把之前以前开发好的模板项目拷贝到这个新的项目里面。那么也就意味着你拷贝过来的项目中的.git污染到你git clone 新项目中的.git
所以我们就需要删除这个.git文件，删除这个文件后，我们本地就和远程仓库也就断开了链接，所以需要我们重新建立链接
```
rm -rf .git  //删除之前的.git 记录
git init //初始化git 命令的所有操作
git add .  //本地仓库添加进来 
git commit -m "up" //记录本地提交的记录
git remote add origin http://******  //和远程创建链接
git branch -a  // 查看所有分支  当你创建完远程链接后 那么本地就会出现远程的分支
git push -u origin master //把本地代码推送到远程master分支上面 （会失败，告知去git pull）
git pull  //把远程代码更新到本地 
```
操作到这个时候,会出现这个东东
>There is no tracking information for the current branch.
Please specify which branch you want to merge with.
See git-pull(1) for details.
git pull <remote> <branch>
If you wish to set tracking information for this branch you can do so with:
git branch --set-upstream-to=origin/<branch> master
```
git pull remote/origin/master
git pull origin/master
```
又出现个这个东东，告诉我没有发现远程这个仓库
>fatal: 'origin/master' does not appear to be a git repository
fatal: Could not read from remote repository.
Please make sure you have the correct access rights
and the repository exists.

于是呢，那么设置远程分支
```
git branch --set-upstream-to=origin/master
git pull //接着从远程去拉去最新的代码 （失败）
git pull origin master --allow-unrelated-histories  //强制拉取远程master 的历史记录
git pull //成功
```
解决冲突
```
git add .
git commit -m "up"
git push 完成
```
场景二：
本地已经开发好了项目，远程也已经创建好了仓库，需要把本地的仓库推送到远程仓库，那么就需要我们把本地和远程的仓库打通，建立起链接
>场景一和场景二类似的操作

