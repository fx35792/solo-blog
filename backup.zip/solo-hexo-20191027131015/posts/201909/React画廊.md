title: React画廊
date: '2019-09-10 09:58:01'
updated: '2019-09-10 11:27:28'
tags: [React]
permalink: /articles/2019/09/10/1568080681512.html
---
![](https://img.hacpai.com/bing/20190206.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


在开发的过程中我们经常会遇到，一组图片，点击任何一个图片，该图片放大弹出来并且可以左右切换这组图片，这组图片我们称为：
* [react-photo-gallery(图片画廊) ](https://github.com/neptunian/react-photo-gallery)
* [react-images(图片灯箱)](https://github.com/jossmac/react-images)
### 第一种方法
![图片画廊](http://resource.sunnyfanfan.com/soloBlog/React/3168340-51825496f5a15d67.png)
![图片灯箱](http://resource.sunnyfanfan.com/soloBlog/React/3168340-3052322c16cf1524.png)
#### 1.安装react-images
```
#版本"^0.5.19"
npm install react-images -S
```
#### 2.安装react-photo-gallery
```
#版本"^6.3.4"
npm install react-photo-gallery -S
```
#### 3.使用
```
//1.组件中引入这两个依赖
import Gallery from 'react-photo-gallery';
import Lightbox from 'react-images';

//2.初始化数据
constructor(props) {
    super(props);
    this.state = {
      imageBoxIsOpen: false,//打开灯箱
      currentImage: 0//默认显示第一张图片
    }
}

//3.打开灯箱，且打开当前灯箱图片
openImageBox = (event, obj) => {
    this.setState({
      currentImage: obj.index,
      imageBoxIsOpen: true,
    });
};
//4.关闭灯箱图片，且恢复初始值数据
  closeImageBox = () => {
    this.setState({
      currentImage: 0,
      imageBoxIsOpen: false,
    });
  };

//5.切换前一张图片操作
  gotoPrevious = () => {
    this.setState({
      currentImage: this.state.currentImage - 1,
    });
  };
//6.切换后一张图片操作
  gotoNext = () => {
    this.setState({
      currentImage: this.state.currentImage + 1,
    });
  };

//7.render 部分
const photos = [
{ src: '../images/photo-1.jpg' },
{ src: '../images/photo-2.jpg' }
]
<Gallery photos={photos} onClick={this.openImageBox}/>
<Lightbox
  images={photos}
  onClose={this.closeImageBox}
  onClickPrev={this.gotoPrevious}
  onClickNext={this.gotoNext}
  currentImage={this.state.currentImage}
  isOpen={this.state.imageBoxIsOpen}
/>
</div>

```
#### 4.demo代码地址
https://github.com/fx35792/React-Gallery1
#### 5.参考网址
[https://github.com/neptunian/react-photo-gallery](https://github.com/neptunian/react-photo-gallery)
[https://github.com/jossmac/react-images](https://github.com/jossmac/react-images)


