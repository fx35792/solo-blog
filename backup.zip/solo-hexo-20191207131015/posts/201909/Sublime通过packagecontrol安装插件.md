title: Sublime 通过package control安装插件
date: '2019-09-21 13:32:55'
updated: '2019-09-21 13:32:55'
tags: [Sublime]
permalink: /articles/2019/09/21/1569043975285.html
---
#### 第一、安装Package Control 插件  
##### 1.安装地址：  
https://packagecontrol.io/installation

通过package control来安装各种插件
#### 第二、安装插件
###### 1.登录下面的网址，搜索和安装自己想要的插件
[Package Control](https://packagecontrol.io/): https://packagecontrol.io/
###### 2.常见的插件
"SideBarEnhancements"
"Alignment",
"All Autocomplete",
"AutoFileName",
"BracketHighlighter",
"CodeFormatter",
"ColorPicker",
"ConvertToUTF8",
"CSS3",
"CSScomb",
"DocBlockr",
"Emmet",
"Git",
"HTML5",
"HTMLAttributes",
"HTMLBeautify",
"JsFormat",
"Markdown Preview",
"Material Theme",
"One Dark Material - Theme",
"Package Control",
"Sass",
"SideBarEnhancements",
"SideBarFolders",
"SublimeLinter",
"SublimeTmpl",
"Tag",
"Themr",
"TrailingSpaces",
"Trimmer"

3.在package control 中你可以看到四部分：
* trending(趋势)
* new(新多)
* popular(流行的，根据个人需求自行安装)
* label(标签)




