title: WebStorm快捷键
date: '2019-10-11 15:05:06'
updated: '2019-10-11 15:05:06'
tags: [Editor]
permalink: /articles/2019/10/11/1570777506636.html
---
![](https://img.hacpai.com/bing/20180611.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```
* shift + Enter 软回车 ,无论在前一行代码的什么位置,都能定位到下一行.
* command 显示/隐藏 左侧面板
* command + b / 点击 定位方法
* command + option + l 代码格式化
* fn+option+f7 查看函数哪里调用过
* command + e 打开最近打开的文件或者项目 (直接支持文件名搜索)
* command + shift + v 选择粘贴剪切板上的内容
* command + d 直接粘贴当前选中的内容
* command + 退格键 删除当前鼠标所在行
* command + option + 左右箭头 定位到上次编辑的位置
* command + option + 上下箭头 依次顺序轮换激活打开的标签页
* command + fn + f12 查看当前页面所有函数
* command + f 当前页搜索
* command + shift + f 全局搜索内容
* command + shift + o 搜索文件
* command + / 注释/取消注释
* /** + Enter 自动生成注释
* command + j 输出模板
* control + tab 切换上次打开的文件
* command + b 跳到变量声明处
* command + x 剪切行
* command + shift + u 切换大小写
* command + l 输入行号，快速定位都某一行

```
