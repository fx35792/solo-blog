title: Axios学习总结
date: '2019-09-06 17:55:13'
updated: '2019-09-08 01:56:37'
tags: [axios]
permalink: /articles/2019/09/06/1567763713585.html
---
#### 一、第1章简介
##### 1.1Axios是什么？
Axios是一个基于promise的HTTP库，类似jquery中的ajax
它可以用于浏览器和node.js中
##### 1.2Axios有哪些特性？
* 支持Promise API
* 拦截请求和相应
* 转换请求数据和相应数据
* 取消请求
* 自动转换JSON数据
* 客户端支持防御XSRF
##### 1.3Aixos浏览器支持
* FireFox 65+
* Chrome 72+
* IE 8+
* Edge
* Safari 9+

#### 二、第2章Axios方法的基本使用
##### 2.1 vue项目的创建
```
#安装vue脚手架
npm install -g @vue/cli

#通过脚手架创建一个vue项目
vue create axios-vue 回车
选择自定义安装 回车
选择Babel、Router、CSS Pre-processors、Linter / Formatter 回车
选择Use history mode for router? y 回车
选择Less 回车
选择ESLint with error prevention only 回车
选择Lint on save	回车
选择In dedicated config files 回车
选择Save this as a preset for future projects?    N 回车
...开始进行下载并且安装依赖

#启动axios-vue
cd axios-vue
npm run serve

#安装axios依赖
npm install axios -S
or
yarn add axios

#手动创建data.json（目录：public/data.json）
{
  "title": "axios vue",
  "createTime": "2019-9"
}

#在home.vue中通过axios请求data.json，并且查看打印结果(src/view/home.vue)
import axios from "axios";
created() {
    axios.get("/data.json").then(res => {
      console.log(res);
    });
}
```
##### 2.2axios请求方法及别名（get、post、put、patch、delete方法）
1. 2-2.vue
```
<template>
  <div class="home"></div>
</template>

<script>
/*
  axios请求方法：get、post、put、patch、delete

  get:获取数据
  post:提交数据（表单提交/文件上传）
  put:更新数据 （将所有的数据推送到后端）
  patch:更新数据 （只将修改的数据推送到后端）
  delete:删除数据

  具体的提交方式是由后端来定义的
 */
import axios from "axios";

export default {
  name: "axios-2",
  created() {
    //http://localhost:8080/data.json?id=1&name=%E5%BC%A0%E4%B8%89
    //get请求第一种方式
    axios
      .get("/data.json", {
        params: {
          id: 1,
          name: "张三"
        }
      })
      .then(res => {
        console.log(res);
      });
    //get请求第二种方式
    axios({
      method: "get",
      url: "/data.json",
      timeout: 1000,
      params: {
        id: 1,
        name: "张三"
      }
    }).then(res => {
      console.log(res);
    });

    //post 存在两种数据格式的提交
    //form-data 表单提交(图片上传、文件上传)
    //application/json

    //post请求第一种方式
    let data = {
      id: 1
    };
    axios.post("/post", data).then(() => {});
    //post请求第二种方式
    axios({
      method: "post",
      url: "/post",
      data: data
    }).then(() => {});

    //form-data的post请求方式
    let formData = new FormData();
    for (let key in data) {
      formData.append(key, data[key]);
    }
    axios.post("/post", formData).then(() => {});

    //那么put、patch也有两种方式类似于get、post，下面的演示咱们就只采取一种方式
    axios.put("/put", data).then(() => {});
    axios.patch("/patch", data).then(() => {});

    //delete请求第一种方式
    axios
      .delete("/delete", {
        params: {
          id: 1
        }
      })
      .then(() => {});
    axios
      .delete("/delete", {
        data: {
          id: 1
        }
      })
      .then(() => {});
    //delete请求第二种方式
    axios({
      method: "delete",
      url: "/delete",
      // params:{id:1},
      data: {
        id: 1
      }
    });
  }
};
</script>

```
2.在router.js当中增加2-2.vue的路由
```
{
      path: '/axios-2',
      name: 'axios-2',
      component: () => import(/* webpackChunkName: "axios-2" */ './views/2-2.vue')
}
```
3.创建一个data.json (public/data.json)
```
{
  "title": "axios vue",
  "createTime": "2019-9"
}
```
4.那么请求地址就是：http://localhost:8080/axios-2

##### 2.3 并发请求
1.2-3.vue页面
```
<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png" />
  </div>
</template>

<script>
/*
  并发请求: 同时进行多个请求，并统一处理返回值
*/
import axios from "axios";

export default {
  name: "axios-2",
  created() {
    //axios.all、axios.spread
    axios.all([axios.get("/data.json"), axios.get("/city.json")]).then(
      axios.spread((dataRes, cityRes) => {
        console.log("dataRes", dataRes);
        console.log("cityRes", cityRes);
      })
    );
  }
};
</script>

```
2.在router.js当中增加2-3.vue的路由
```
{
      path: '/axios-3',
      name: 'axios-3',
      component: () => import(/* webpackChunkName: "axios-3" */ './views/2-3.vue')
},
```
3.创建一个data.json (public/city.json)

```
{
  "name": "北京"
}
```

4.那么请求地址就是：http://localhost:8080/axios-3
#### 三、第3章Axios方法深入
##### 3.1创建axios实例
1.3-1.vue页面
```
<template>
  <div class="home"></div>
</template>

<script>
/*
  axios的实例
  为什么我们要使用axios的实例呢？
  因为在开发的过程中，我们可能会有不同的baseURL、timeout
*/
import axios from "axios";

export default {
  name: "axios3-1",
  created() {
    //axios的实例
    let axios1 = axios.create({
      baseURL: "http://localhost:8080",
      timeout: 1000
    });
    let axios2 = axios.create({
      baseURL: "https://easy-mock.com/mock/5d5fb2ce9b58ad2249ff6c2b/mockapi",
      timeout: 5000
    });

    axios1.get("/data.json").then(res => {
      console.log(res);
    });
    axios2.get("/table/high/list").then(res => {
      console.log(res);
    });
  }
};
</script>

```
2.在router.js当中增加3-1.vue的路由
```
{
      path: '/axios3-1',
      name: 'axios3-1',
      component: () => import(/* webpackChunkName: "axios3-1" */ './views/3-1.vue')
}
```
3.那么请求地址就是：[http://localhost:8080/axios3-1](http://localhost:8080/axios3-1)
##### 3.2 axios基本的配置参数,以及在开发中的应用
1.3-2.vue页面
```
<template>
  <div class="home"></div>
</template>

<script>
import axios from "axios";

export default {
  name: "axios3-2",
  created() {
    //第一部分：axios基本的配置参数有哪些
    axios.create({
      baseURL: "http://localhost:8080", //请求域名，基本地址
      timeout: 1000, //请求超时时长(ms)
      method: "get", //请求方式（post、put、patch、delete）
      url: "/data.json", //请求路径（接口）
      headers: {
        token: ""
      }, //请求头
      params: {}, //请求参数拼接在url中
      data: {} //请求参数放在请求体里面
    });
    
    //第二部分：axios三种参数配置方式以及优先级
    //1.aixos的全局配置(优先级：低)
    axios.defaults.timeout = 1000;
    axios.defaults.baseURL = "http://localhost:8080";
    //2.axios的实例配置(优先级：中)
    let instance = axios.create();
    instance.defaults.timeout = 3000;
    //3.axios的请求配置(优先级：高)
    instance.get("/data.json", {
      timeout: 5000
    });

    //第三部分：axios实例在实际开发中的应用
    //创建axios1实例
    let axios1 = axios.create({
      baseURL: "http://localhost:8080",
      timeout: 1000
    });
    //创建axios2实例
    let axios2 = axios.create({
      baseURL: "https://easy-mock.com/mock/5d5fb2ce9b58ad2249ff6c2b/mockapi",
      timeout: 3000
    });

    //在axios1实例中设计的参数有：baseURL、timeout:1000、method、params
    axios1
      .get("/data.json", {
        params: {
          id: 1
        }
      })
      .then(res => {
        console.log(res);
      });
    //在axios1实例中设计的参数有：baseURL、timeout:5000、method、params
    axios2
      .get("/table/high/list", {
        timeout: 5000,
        params: {
          id: 1
        }
      })
      .then(res => {
        console.log(res);
      });
  }
};
</script>

```
2.在router.js当中增加3-2.vue的路由
```
{
      path: '/axios3-2',
      name: 'axios3-2',
      component: () => import(/* webpackChunkName: "axios3-2" */ './views/3-2.vue')
}
```
3.那么请求地址就是：[http://localhost:8080/axios3-2](http://localhost:8080/axios3-2)
##### 3.3 axios拦截器
1.3-3.vue页面
```
<template>
  <div class="home"></div>
</template>

<script>
/*
  拦截器：在请求或者响应被处理前拦截他们

  let instance = axios.create()
  请求拦截器 instance.interceptors.request.use(config=>return config,err=>return Promise.reject(err))
  响应拦截器 instance.interceptors.re.use(config=>return config,err=>return Promise.reject(err))
  取消拦截器 
*/
import axios from "axios";
import { Promise } from "q";
export default {
  name: "axios3-3",
  created() {
    let instance = axios.create({});
    //请求拦截器
    instance.interceptors.request.use(
      config => config,
      err => Promise.reject(err)
    );
    //响应拦截器
    instance.interceptors.response.use(res => res, err => Promise.reject(err));

    //取消拦截器（了解）
    let interceptors = axios.interceptors.request.use(config => {
      config.headers = {
        auth: true
      };
      return config;
    });
    axios.interceptors.request.eject(interceptors);

    //例子 登录状态（token:''） 不需要登录的接口
    let instance1 = axios.create({});
    instance1.interceptors.request.use(
      config => {
        config.headers.token = "";
        return config;
      },
      err => {
        return Promise.reject(err);
      }
    );
    //需要登录的接口
    let instance2 = axios.create({});
    instance2.get("/data.json");

    //移动端开发的接口
    let instance3 = axios.create({});
    instance3.interceptors.request.use(config => {
      $("#modal").show(); //loading 显示
      return config;
    });
    instance3.interceptors.response.use(
      res => {
        $("#modal").hide(); //loading 隐藏
        return res;
      },
      err => {
        $("#modal").hide(); //loading 隐藏
        return Promise.reject(err);
      }
    );
  }
};
</script>

```
2.在router.js当中增加3-3.vue的路由
```
{
      path: '/axios3-3',
      name: 'axios3-3',
      component: () => import(/* webpackChunkName: "axios3-3" */ './views/3-3.vue')
}
```
3.那么请求地址就是：[http://localhost:8080/axios3-3](http://localhost:8080/axios3-3)
##### 3.4 axios错误处理
1.3-4.vue
```
<template>
  <div class="home"></div>
</template>

<script>
/*
  错误处理: 请求错误时进行的处理
*/
import axios from "axios";
import { Promise } from "q";
import { Toast } from "vant";
export default {
  name: "axios3-4",
  created() {
    axios.interceptors.request.use(
      config => {
        return config;
      },
      err => {
        return Promise.reject(err);
      }
    );
    axios.interceptors.response.use(
      res => {
        return res;
      },
      err => {
        return Promise.reject(err);
      }
    );
    axios
      .get("/data.json")
      .then(res => {
        console.log(res);
      })
      .catch(err => {
        console.log("err", err);
      });

    //例子: 在实际开发过程中，一般添加统一的错误处理
    let intance = axios.create({});
    intance.interceptors.request.use(
      config => {
        return config;
      },
      err => {
        //请求错误 一般http状态码以4开头，常见: 401超时，404 not found
        Toast.loading({
          mask: false,
          message: "加载中..."
        });
        return Promise.reject(err);
      }
    );
    intance.interceptors.response.use(
      res => {
        return res;
      },
      err => {
        //请求错误 一般http状态码以5开头，常见: 500系统错误，502系统重启
        Toast.loading({
          mask: false,
          message: "加载中..."
        });
        return Promise.reject(err);
      }
    );
    intance
      .get("/data1.json")
      .then(res => {
        console.log(res);
      })
      .catch(err => {
        console.log(err);
      });
  }
};
</script>

```
2.在router.js当中增加3-4.vue的路由
```
{
      path: '/axios3-4',
      name: 'axios3-4',
      component: () => import(/* webpackChunkName: "axios3-4" */ './views/3-4.vue')
}
```
3.安装vue的一个UI组件库：vant 、babel-plugin-import
```
npm install vant -S
npm install babel-plugin-import -D
```
4.配置babel.config.js
```
module.exports = {
  presets: [
    '@vue/app'
  ],
  plugins: [
    ['import', {
      libraryName: 'vant',
      libraryDirectory: 'es',
      style: true
    }, 'vant']
  ]
}

```
5.那么请求地址就是：[http://localhost:8080/axios3-4](http://localhost:8080/axios3-4)
##### 3.5 axios 取消请求操作
1.3-5.vue页面
```
<template>
  <div class="home"></div>
</template>

<script>
/*
  取消请求: 用于取消正在进行的http请求（了解）
*/
import axios from "axios";

export default {
  name: "axios3-5",
  created() {
    let source = axios.CancelToken.source();
    axios
      .get("/data.json", {
        cancelToken: source.token
      })
      .then(res => {
        console.log(res);
      })
      .catch(err => {
        console.log(err);
      });

    //取消请求操作(message 可选)
    source.cancel("cancel http");

    //什么情况下可能用到取消请求
    //在执行大量导出数据、或者查询数据的时候，请求时间过长3-5秒，这个过程我们可以进行取消请求的操作
  }
};
</script>

```
2.在router.js当中增加3-5.vue的路由
```
{
      path: '/axios3-5',
      name: 'axios3-5',
      component: () => import(/* webpackChunkName: "axios3-5" */ './views/3-5.vue')
}
```
3.那么请求地址就是：[http://localhost:8080/axios3-5](http://localhost:8080/axios3-5)
#### 四、第4章Axios实战
##### 4.1
##### 4.2
##### 4.3
##### 4.4
##### 4.5
##### 4.6
##### 4.7
##### 4.8
##### 4.9
#### 五、第5章Axios总结
##### 5.1总结
[代码仓库地址: https://github.com/fx35792/axios-vue](https://github.com/fx35792/axios-vue)
