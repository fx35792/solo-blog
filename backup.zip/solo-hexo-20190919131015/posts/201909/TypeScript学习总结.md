title: TypeScript学习总结
date: '2019-09-13 23:14:43'
updated: '2019-09-14 01:59:13'
tags: [TypeScript]
permalink: /articles/2019/09/13/1568387683306.html
---
![](https://img.hacpai.com/bing/20181222.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

#### 第一章 基础篇
##### 1.1 TypeScript的简介
1.定义：
TypeScript是拥有类型系统的JavaScript的超集，可以编译成为纯JavaScript
2.特性
* 类型检查
* 语言扩展
* 工具属性

3.为什么要使用TypeScript？
结合vscode的自动补全、导航和重构功能，这使得接口定义可以直接代替文档；
提高开发效率，降低维护成本
帮助团队重塑“类型思维”，
接口的提供方将被迫思考API的边界，使得“代码的编写者”蜕变为“代码的设计者”


如果JavaScript是一匹“野马”；
那么TypeScript将是束缚这匹野马的“缰绳”;
作为“骑士”的开发者，自然可以张开双臂、放飞自我；
如果不是技艺超群，恐怕会摔得很惨，然而如果抓住了“缰绳”呢？
开发者们既可以闲庭信步，亦可策马扬鞭。

这就是TypeScript的价值，可以让前端在开发道的路上，走的更稳，走的更远。

##### 1.2 基础类型
1.什么是强类型语言呢？
强类型语言：不允许改变变量的数据类型，除非进行强制类型转换
2.什么是弱类型语言呢？
弱类型语言：变量可以被赋予不同的数据类型
```
let x = 1;
let y = true;
x = y;
打印x: true

let z = "a";
x = z;
打印x: "a"
```
3.什么是静态型语言呢？
静态型语言：在"编译阶段"确定所有变量的类型
4.什么是动态型语言呢？
动态型语言：在"执行阶段"确定所有变量的类型
![http://resource.sunnyfanfan.com/soloBlog/TypeScript/1.png](http://resource.sunnyfanfan.com/soloBlog/TypeScript/1.png)
![http://resource.sunnyfanfan.com/soloBlog/TypeScript/2.png](http://resource.sunnyfanfan.com/soloBlog/TypeScript/2.png)
![http://resource.sunnyfanfan.com/soloBlog/TypeScript/3.png](http://resource.sunnyfanfan.com/soloBlog/TypeScript/3.png)
![http://resource.sunnyfanfan.com/soloBlog/TypeScript/4.png](http://resource.sunnyfanfan.com/soloBlog/TypeScript/4.png)

5.TypeScript属于哪类行语言呢？
TypeScript 是 JavaScript 的强类型版本
##### 1.3 第一个TypeScript程序
1.安装NodeJS
http://nodejs.cn/
2.全局安装typescript
```
npm install typescript -g
```
3.创建一个typescript-study的文件目录,并且terminal切到这个目录下面
4.生成package.json配置文件
```
npm init -y
```
5.生成tsconfig.js配置文件
```
tsc --init
```
6.安装webpack相关依赖、安装typescript的相关依赖
```
npm install webpack webpack-cli webpack-dev-server html-webpack-plugin clean-webpack-plugin webpack-merge -D

npm install ts-loader typescript -D
```
7.创建src目录、src/tpm/index.html、src/index.ts
8.创建build目录、build/webpack.base.config.js、build/webpack.config.js、build/webpack.dev.config.js、build/webpack.pro.config.js
9.在package.json文件中编写启动命令和打包命令
```
"start": "webpack-dev-server --mode=development --config ./build/webpack.config.js",

"build": "webpack --mode=production --config ./build/webpack.config.js"
```

10.代码实现地址：
https://github.com/fx35792/typescript-study

![http://resource.sunnyfanfan.com/soloBlog/TypeScript/5.png](http://resource.sunnyfanfan.com/soloBlog/TypeScript/5.png)

##### 1.4 基本类型

![http://resource.sunnyfanfan.com/soloBlog/TypeScript/6.png](http://resource.sunnyfanfan.com/soloBlog/TypeScript/6.png)

1.类型注解
作用：相当于强类型语言中的类型生命
语法：（变量/函数）：	type

##### 1.5 
##### 1.6 
##### 1.7 
##### 1.8 
##### 1.9 
##### 1.10
##### 1.11
##### 1.12
##### 1.13
##### 1.14
##### 1.15
##### 1.16
##### 1.17  
#### 第二章 工程篇
#### 第三章 实战篇
