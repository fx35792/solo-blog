title: Iterm
date: '2019-09-16 16:02:04'
updated: '2019-09-16 16:02:04'
tags: [TOOLS]
permalink: /articles/2019/09/16/1568620924416.html
---
![](https://img.hacpai.com/bing/20190522.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 第一、iTerm的安装
http://www.iterm2.com/
#### 第二、ohmyz的安装
  地址：http://ohmyz.sh/
#### 第三配置安装：
```
$ sh -c "$(curl -fsSL https://raw.github.com/robbyrussell/oh-my-zsh/master/tools/install.sh)"
```
第四、iTerm的快捷键
```
command+, 弹出偏好设置窗口
command+o 弹出profiles界面
command+d 分割窗口
command+t 新建选项卡窗口
command+w 关闭窗口
command+数字 切换到第(x)个选项卡窗口
command+左/右箭头 切换选项卡窗口，按方向依次切换
command+~ 隐藏/显示iTerm2
fn+左箭头(或者ctrl+a) 控制光标至开头
fn+右箭头(或者ctrl+e) 控制光标至结尾
command+f 查找
command+e+r(或者command+k) 清屏
control+r 匹配之前输入过的命令
```
第五：iTerm的一些小技巧
http://littlewhite.us/archives/393

