title: React、Redux、MobX 学习链接汇总
date: '2019-09-10 15:18:45'
updated: '2019-09-11 16:53:33'
tags: [React]
permalink: /articles/2019/09/10/1568099925752.html
---
#### 一、React、Redux、MobX
React是构建用户界面的 JavaScript 库,简单的数据交互React自己就可以满足
但是针对复杂页面之间的数据传递就需要借助Redux或者MobX

1.React官网：https://react.docschina.org/
2.Redux官网：https://www.redux.org.cn/
3.MobX官网：https://cn.mobx.js.org/

#### 二、Ant About React

##### 1.Ant-Ui框架相关
Ant Design：针对PC端的React Ui 框架
[Ant Design：http://ant.design](http://ant.design/)
[Ant Design Git：https://github.com/ant-design/ant-design](https://github.com/ant-design/ant-design)

Ant Design Mobile：针对Mobile端的React Ui 框架
[Ant Design Mobile：https://mobile.ant.design/index-cn](https://mobile.ant.design/index-cn)   
[Ant Design Mobile Git：https://github.com/ant-design/ant-design-mobile](https://github.com/ant-design/ant-design-mobile)

##### 2.Umi
Umi：React 应用开发框架
https://umijs.org/zh/guide/

##### 3.Dva
Dva：数据流前端框架
https://dvajs.com/guide/

##### 4.Ant Design Pro
Ant Design Pro：React+Ant+Redux+Umi+Dva结合,是一个企业级中后台前端/设计解决方案
[Ant Design Pro：http://pro.ant.design/](http://pro.ant.design/)  
[Ant Design Pro Git：https://github.com/ant-design/ant-design-pro](https://github.com/ant-design/ant-design-pro)

注释：
* roadhog 是基于 webpack 的封装工具，目的是简化 webpack 的配置
* umi 可以简单地理解为 roadhog + 路由，思路类似 next.js/nuxt.js，辅以一套插件机制，目的是通过框架的方式简化 React 开发
* dva 目前是纯粹的数据流，和 umi 以及 roadhog 之间并没有相互的依赖关系，可以分开使用也可以一起使用，个人觉得 [umi + dva 是比较搭的](https://github.com/sorrycc/blog/issues/66)

#### 三、React常用的脚手架
1.[create-react-app](https://github.com/facebook/create-react-app)
2.[Umi](https://umijs.org/zh/guide/)
3.[Dva-cli](https://dvajs.com/guide/getting-started.html#%E5%AE%89%E8%A3%85-dva-cli)

#### 四、React一些语法规范
[https://github.com/dwqs/react-style-guide](https://github.com/dwqs/react-style-guide)

#### 五、更多React相关
React Awesome
[https://github.com/enaqx/awesome-react](https://github.com/enaqx/awesome-react)

#### 六、其他
1.Redux和Mobx选择？https://juejin.im/post/5a7fd72c5188257a766324ae

