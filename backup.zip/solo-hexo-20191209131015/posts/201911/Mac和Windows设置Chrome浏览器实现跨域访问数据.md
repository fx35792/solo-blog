title: Mac和Windows设置Chrome浏览器实现跨域访问数据
date: '2019-11-07 09:07:11'
updated: '2019-11-07 09:07:43'
tags: [浏览器]
permalink: /articles/2019/11/07/1573088831567.html
---
##### Mac
打开terminal 运行 openChrome.bash
```
//openChrome.bash
cd /Applications/Google\ Chrome.app
open -a "Google Chrome" --args --disable-web-security --user-data-dir
```
#### Windows
右击桌面图标-->在目标一行后面空格加入" --args --disable-web-security --user-data-dir"
应用---确定


