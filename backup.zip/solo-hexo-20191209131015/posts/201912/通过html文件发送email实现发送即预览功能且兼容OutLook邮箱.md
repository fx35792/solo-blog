title: 通过html文件发送email实现发送即预览功能，且兼容OutLook邮箱
date: '2019-12-02 17:50:36'
updated: '2019-12-02 17:50:36'
tags: [待分类]
permalink: /articles/2019/12/02/1575280236703.html
---
![](https://img.hacpai.com/bing/20190227.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

前段时间，帮朋友做一个m和pc的web页面
#### 需求：
1、按照效果图切图，通过代码实现效果图样式
2、支持邮件预览(尤其是outlook)
#### 准备：
当看到效果图的时候，觉得很简单没有什么难点的内容，自己花了一两个小时就搞定了(代码已经完成了二分之一，我在上面接着进行开发)。在pc和手机上简单的测试了几遍后，发现没啥问题，就发给朋友了。朋友看到后，提出了几个细节的修改后，说没啥大问题。可是万万没想到的是，这个静态的html文件要通过邮件的方式进行发送预览，然后我就打开qq邮箱把html代码发送了一份给自己的邮箱，自己打开邮箱一看，页面各种错乱，完全没有样式。
#### 问题：
1.页面严重错乱
原因：邮箱把html除了body外的标签都给过滤了，而自己的样式是在head的style文件中写的
解决方案：
通过：http://premailer.dialect.ca/ 工具
给标签添加上行内样式
2.字体行高行距不一致
原因：采用了外部的字体链接文件库，自定义了几个比较好看的字体文件，在html中使用，但是各个邮箱对字体识别都是不一样的，网页的还能捕获多一些字体文件，但是客户端app那基本上就是系统的默认字体
解决方案：
字体改为通用字体：**font-family:Arial, Helvetica, sans-serif;**
或者
将华丽的字体部分改为：**图片**
3.各个邮箱之间的兼容问题（尤其是兼容outlook邮箱）
通过前两部的改，其他邮箱大体都ok了，但是发送到outlook邮箱，网页端的页面好好一些，客户端不管是pc客户端还是手机客户端，都存在不居中，间距不等等等问题
解决方案：
首先是查阅各种网上资料，给出的答案是布局要才用table，看到这个，哭的心都有了，意味着全部重构代码，但是没办还是重新做了。
通过table重构后，测试的过程中，还是存在上述问题，改的完全开始怀疑人生了，但是仔细阅读后，样式不能有float，position，margin，background，#000改写成#000000的样式和div、p、span等标签，what？这样怎么写？习惯了上面这些标签和样式和布局的自己，这怎么这么坑爹呢？？？，还是少抱怨，冷静，平静下来之后，再认真分析，那只能用最传统的布局方式了table布局，比如单元格合并，单元格之间上下水平居中，
* table: 
```
<table width="680" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
</table>
```
* td:
```
<td width="220" rowspan="2" style="border-collapse:collapse"></td>
<td width="220" colspan="2" style="border-collapse:collapse"></td>
```
* img
要给宽、高；要是块级元素；boder要为：0
```
<img src="https://www.baidu.com/1.jpg" width="460" height="160" style="display:block">
```
* a
```
<a href="http://www.baidu.com/" rel="noopener" target="_blank">
```
* 对齐方式
```
align="center" valign="middle"
```
* 空格
```
&nbsp; 或者 &emsp;
```
#### 总结
后来想想为什么要这么代码复杂化和简单化，后来想了想：
不让引入各种外部文件，防止各种病毒脚本的传播。
采用内敛是：是因为自己的网页是嵌套在别人的邮箱的网页中的，为了不让别人的样式污染到自己的样式，所以采用内敛是样式。
table布局方式：可能是为了兼容各种浏览器或者设备。

要对table thead tr td tbody 以及他们的属性比较熟悉。
要对table的嵌套、单元格的合并比较熟悉。

下面粘贴代码，共参考：
```
<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#f3f3f3">
    <tbody>
        <tr>
            <td>
                <table width="680" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                    <tbody>
                        <tr>
                            <td>
                                <table width="680" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse">
                                    <tbody>
                                        <tr>
                                            <td width="220" rowspan="2" style="border-collapse:collapse"><img src="2.jpg" width="220" height="211" style="display:block"></td>
                                            <td width="460" height="160" style="border-collapse:collapse"><img src="3.jpg" width="460" height="160" style="display:block"></td>
                                        </tr>
                                        <tr>
                                            <td width="460" height="50" bgcolor="#df0210" style="color:#FFF; font-family:Arial, Helvetica, sans-serif; font-size:24px">&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;IN JAN 2020</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table width="680" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse">
                                    <tbody>
                                        <tr>
                                            <td width="254" style="border-collapse:collapse"><a href="http://baidu.com/" rel="noopener" target="_blank"><img src="4.jpg" width="254" height="341" style="display:block"></a></td>
                                            <td width="173" style="border-collapse:collapse"><img src="41.jpg" width="173" height="341" style="display:block"></td>
                                            <td width="253" style="border-collapse:collapse"><a href="https://baidu.com" rel="noopener" target="_blank"><img src="4.jpg" width="253" height="341" style="display:block"></a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td style=" padding:45px 0 50px">
                                <table width="560" align="center" cellpadding="0" cellspacing="0" style="border:#dd0011 solid 2px;border-collapse:collapse">
                                    <tbody>
                                        <tr>
                                            <td style="padding: 20px; font-size: 14px;">
                                                <font face="Arial">Dear Henkel employees,</font><br>
                                                <br>
                                                <font style="font-family: Arial, Helvetica, sans-serif;">hello everyhello everyhello everyhello everyhello everyhello everyhello everyhello everyhello everyhello everyhello everyhello every.</font>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table width="680" border="0" cellspacing="0" cellpadding="0">
                                    <tbody>
                                        <tr>
                                            <td colspan="2"><img src="2.jpg" width="520" height="5"></td>
                                        </tr>
                                        <tr>
                                            <td width="380" height="45" bgcolor="#df0210" valign="middle" style="color:#FFF; font-size:24px; text-indent:60px; font-family:Arial, Helvetica, sans-serif"><strong>HIGHLIGHTS IN NOV</strong></td>
                                            <td height="45"><img src="3.jpg" width="35" height="45" style="display:block"></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td style="padding:40px 70px 45px; font-size:14px; font-family: Arial, Helvetica, sans-serif">Our exceptional team is our biggest asset. We are proud to be a melting pot of skills, knowledge,
                                and ideas from our employees.</td>
                        </tr>
                        <tr>
                            <td>
                                <table width="560" border="0" align="center" cellpadding="0" cellspacing="0">
                                    <tbody>
                                        <tr>
                                            <td>
                                            	<a href="http://baidu.com" rel="noopener" target="_blank">
                                            		<img src="1.jpg">
                                            		<br><br>
                                            	</a>
                                        	</td>
                                            <td><a href="http://baidu.com" rel="noopener" target="_blank"><img src="1.jpg"><br><br></a></td>
                                            <td><a href="http://baidu.com" rel="noopener" target="_blank"><img src="2.jpg"><br><br></a></td>
                                            <td><a href="http://baidu.com" rel="noopener" target="_blank"><img src="2.jpg"><br><br></a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td height="286" align="center" valign="middle">
                            	<a href="https://baidu.com" rel="noopener" target="_blank">
                            		<img src="1.jpg" width="165" height="165">
                            	</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
```






