title: Element-UI中表格单元格中多个按钮时不换行
date: '2019-09-25 17:01:44'
updated: '2019-09-27 08:42:17'
tags: [Vue]
permalink: /articles/2019/09/25/1569402104200.html
---
![](https://img.hacpai.com/bing/20190614.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


今天在开发vue项目中，UI框架使用的是Element-Ui，有一个table表格的列表数据，其中有一个列是操作，需要有三个按钮，很不辛的是，当把三个按钮放上去的时候，两个按钮在一行，第三个按钮进行了换行，这么的话美观上大打折扣.
![图片1](http://resource.sunnyfanfan.com/soloBlog/Vue/2019092501.png)

#### 第一种方案
通过修改Element-Ui样式来完善我们想要的结果（不推荐）：

![图片2](http://resource.sunnyfanfan.com/soloBlog/Vue/2019092502.png)

样式：
```
//tableList 是给table的样式名称
.tableList {
  overflow: auto;
}
.tableList /deep/ .el-table__header {
  table-layout: auto;//将表头的fixed值改为auto
}
.tableList /deep/ .el-table__body {
  table-layout: auto;//将表身体的fixed值改为auto
}
.tableList /deep/ .el-table__body-wrapper {
  height: auto !important;
}
.tableList /deep/ .el-table__row td:last-child .cell {
  width: 200px;//将表头的最后一格值改为200像素，这是一个小小的局限性
}
.tableList /deep/ .el-table__header th:last-child .cell {
  width: 200px;//将表身体的最后一格值改为200像素，这是一个小小的局限性
}
```
#### 第二种通过设置宽度
给单元格设置指定的宽度，预留一个不给它设置宽度让它自适应，这个例子中我们把操作模块三个按钮的显示的单元格宽度不给值，让他自适应，也能达到图二的效果。

```
<el-table
        :data="searchList"
        border
        :stripe="true"
        size="mini"
        style="width:100%"
        :height="tableHeight"
        v-loading="tableLoading"
        class="tableList"
      >
        <el-table-column prop="targetSystemId" label="#" width="100"></el-table-column>
        <el-table-column prop="targetSystemName" label="目标系统名称" width="150"></el-table-column>
        <el-table-column prop="supplier" label="供应商" width="150"></el-table-column>
        <el-table-column prop="newEnergyCharge" label="新能源负责人" width="150"></el-table-column>
        <el-table-column prop="supplierCharge" label="供应商负责人" width="150"></el-table-column>
        <el-table-column prop="pushCount" label="推送次数" width="150"></el-table-column>
        <el-table-column prop="errorCount" label="错误次数" width="150"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button-group>
              <el-button
                size="mini"
                type="primary"
                @click.native="handleOpenEditTargetDialog(scope.row)"
              >编辑</el-button>
              <el-button size="mini" type="primary" @click="handleOpenConfig(scope.row)">配置</el-button>
              <el-button size="mini" type="danger" @click="handleDelete(scope.row)">删除</el-button>
            </el-button-group>
          </template>
        </el-table-column>
</el-table>


<style>
.tableList {
  overflow: auto;
}
.tableList /deep/ .el-table__body-wrapper {
  height: auto !important;
}
.tableList::before {
  background-color: transparent !important;
}
</style>
```
