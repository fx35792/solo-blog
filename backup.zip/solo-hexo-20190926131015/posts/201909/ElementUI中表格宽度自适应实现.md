title: Element-UI中表格宽度自适应实现
date: '2019-09-25 17:01:44'
updated: '2019-09-25 17:17:37'
tags: [Vue]
permalink: /articles/2019/09/25/1569402104200.html
---
![](https://img.hacpai.com/bing/20190614.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

今天在开发vue项目中，UI框架使用的是Element-Ui，有一个table表格的列表数据，其中有一个列是操作，需要有三个按钮，很不辛的是，当把三个按钮放上去的时候，两个按钮在一行，第三个按钮进行了换行，这么的话美观上打了大大的折扣.
![图片1](http://resource.sunnyfanfan.com/soloBlog/Vue/2019092501.png)

通过通过篡改Element-Ui样式来完善我们想要的结果:

![图片2](http://resource.sunnyfanfan.com/soloBlog/Vue/2019092502.png)

样式：
```
//tableList 是给table的样式名称
.tableList {
  overflow: auto;
}
.tableList /deep/ .el-table__header {
  table-layout: auto;//将表头的fixed值改为auto
}
.tableList /deep/ .el-table__body {
  table-layout: auto;//将表身体的fixed值改为auto
}
.tableList /deep/ .el-table__body-wrapper {
  height: auto !important;
}
.tableList /deep/ .el-table__row td:last-child .cell {
  width: 200px;//将表头的最后一格值改为200像素，这是一个小小的局限性
}
.tableList /deep/ .el-table__header th:last-child .cell {
  width: 200px;//将表身体的最后一格值改为200像素，这是一个小小的局限性
}
```
这样实现其实称不上自适应宽度，只能说设置指定宽度。
