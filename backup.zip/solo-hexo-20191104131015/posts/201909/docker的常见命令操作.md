title: docker的常见命令操作
date: '2019-09-06 11:03:50'
updated: '2019-09-07 13:50:32'
tags: [docker]
permalink: /articles/2019/09/06/1567739030523.html
---
![](https://img.hacpai.com/bing/20171225.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

#### 一、linux系统安装docker
```
#安装 Docker
yum -y install docker

#启动 Docker 后台服务
service docker start

#测试运行 hello-world
docker run hello-world
```
#### 二、docker 常见命令操作
```
#查看都有哪些镜像(eg:mysql)
docker search mysql

#查看安装的镜像
docker images

#删除下载的镜像
docker rmi 镜像名称

#下载镜像
docker pull mysql:5.7

#安装镜像、执行、创建、退出
1、docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=123456 -d mysql:5.7
2、docker exec -it mysql bash（执行mysql）
3、mysql -uroot -p123456 （登录数据库）
4、create database solo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;（创建solo数据库）
5、exit （退出表）
6、exit （退出mysql数据库）

#查看所有运行这的服务
docker ps -a

#查看服务运行的log（来捕获异常）
docker logs mysql

#开启服务
docker start mysql

#重启服务
docker restart mysql

#停止服务
docker stop mysql

#杀死服务
docker kill mysql
```

